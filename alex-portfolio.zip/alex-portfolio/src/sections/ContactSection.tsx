import { useState, type FormEvent } from 'react';
import { ArrowUp, Github, Linkedin, Mail, Twitter } from 'lucide-react';
import FadeIn from '../components/FadeIn';
import ContactButton from '../components/ContactButton';
import { contact, site } from '../data/content';

type Status = 'idle' | 'sending' | 'success' | 'error';

const fieldClass =
  'w-full border-b-2 border-[#D7E2EA]/30 bg-transparent py-4 text-base font-light text-[#D7E2EA] placeholder:text-[#D7E2EA]/40 transition-colors focus:border-[#D7E2EA] focus:outline-none';
const labelClass = 'text-xs uppercase tracking-widest text-[#D7E2EA]/60';

export default function ContactSection() {
  const [status, setStatus] = useState<Status>('idle');
  const [message, setMessage] = useState('');
  const [budget, setBudget] = useState('');

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);

    if (data.get('_gotcha')) return; // honeypot filled → bot

    const email = String(data.get('email') || '');
    if (!String(data.get('name') || '').trim() || !/^\S+@\S+\.\S+$/.test(email) || !String(data.get('message') || '').trim()) {
      setStatus('error');
      setMessage('Please fill in your name, a valid email and a message.');
      return;
    }

    if (site.formspreeEndpoint.includes('YOUR_FORM_ID')) {
      setStatus('error');
      setMessage(`The form isn't connected yet. Email me directly at ${site.email}.`);
      return;
    }

    setStatus('sending');
    try {
      const res = await fetch(site.formspreeEndpoint, {
        method: 'POST',
        body: data,
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) throw new Error('Request failed');
      form.reset();
      setBudget('');
      setStatus('success');
      setMessage(contact.successMessage);
    } catch {
      setStatus('error');
      setMessage(`Message not sent. Try again, or email me at ${site.email}.`);
    }
  }

  const socials = [
    { label: 'GitHub', href: site.socials.github, Icon: Github },
    { label: 'LinkedIn', href: site.socials.linkedin, Icon: Linkedin },
    { label: 'X (Twitter)', href: site.socials.twitter, Icon: Twitter },
    { label: 'Email', href: `mailto:${site.email}`, Icon: Mail },
  ];

  return (
    <section
      id="contact"
      className="relative z-30 -mt-10 rounded-t-[40px] bg-[#0C0C0C] px-5 pb-10 pt-20 sm:-mt-12 sm:rounded-t-[50px] sm:px-8 sm:pt-24 md:-mt-14 md:rounded-t-[60px] md:px-10 md:pt-32"
      style={{ paddingBottom: 'max(2.5rem, env(safe-area-inset-bottom, 0px))' }}
    >
      <div className="mx-auto flex max-w-3xl flex-col items-center gap-8 text-center">
        <FadeIn
          as="h2"
          y={40}
          className="hero-heading font-black uppercase leading-none tracking-tight"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          {contact.heading}
        </FadeIn>
        <FadeIn
          as="p"
          delay={0.1}
          className="max-w-[520px] font-light text-[#D7E2EA]"
          style={{ fontSize: 'clamp(1rem, 1.8vw, 1.25rem)' }}
        >
          {contact.subtext}
        </FadeIn>
      </div>

      <FadeIn delay={0.15} className="mx-auto mt-14 max-w-3xl md:mt-20">
        <form onSubmit={handleSubmit} noValidate className="grid grid-cols-1 gap-x-8 gap-y-8 md:grid-cols-2">
          <input type="text" name="_gotcha" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />

          <label className="flex flex-col gap-1">
            <span className={labelClass}>Name</span>
            <input name="name" type="text" required autoComplete="name" placeholder="Your name" className={fieldClass} />
          </label>
          <label className="flex flex-col gap-1">
            <span className={labelClass}>Email</span>
            <input name="email" type="email" required autoComplete="email" placeholder="you@company.com" className={fieldClass} />
          </label>
          <label className="flex flex-col gap-1 md:col-span-2">
            <span className={labelClass}>Budget</span>
            <select
              name="budget"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              className={`${fieldClass} cursor-pointer ${budget ? '' : '!text-[#D7E2EA]/40'}`}
            >
              <option value="" disabled className="bg-[#0C0C0C]">
                Select a range
              </option>
              {contact.budgets.map((b) => (
                <option key={b} value={b} className="bg-[#0C0C0C] text-[#D7E2EA]">
                  {b}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1 md:col-span-2">
            <span className={labelClass}>Message</span>
            <textarea name="message" required rows={4} placeholder="Tell me about your project" className={`${fieldClass} resize-none`} />
          </label>

          <div className="flex flex-col items-center gap-4 pt-4 md:col-span-2">
            <ContactButton type="submit" label={status === 'sending' ? 'Sending…' : 'Send Message'} disabled={status === 'sending'} />
            <p role="status" aria-live="polite" className={`min-h-[1.5rem] text-center text-sm ${status === 'error' ? 'text-[#F59E8B]' : 'text-[#D7E2EA]/80'}`}>
              {status === 'success' || status === 'error' ? message : ''}
            </p>
          </div>
        </form>
      </FadeIn>

      <FadeIn delay={0.1} className="mt-16 flex flex-col items-center gap-8 md:mt-20">
        <a
          href={`mailto:${site.email}`}
          className="font-medium text-[#D7E2EA] underline-offset-8 transition-opacity hover:underline"
          style={{ fontSize: 'clamp(1.5rem, 4vw, 3rem)' }}
        >
          {site.email}
        </a>
        <ul className="flex gap-3">
          {socials.map(({ label, href, Icon }) => (
            <li key={label}>
              <a
                href={href}
                target={href.startsWith('mailto:') ? undefined : '_blank'}
                rel="noopener noreferrer"
                aria-label={label}
                className="flex h-12 w-12 items-center justify-center rounded-full border border-[#D7E2EA]/30 text-[#D7E2EA] transition-colors duration-200 hover:bg-[#D7E2EA]/10 md:h-14 md:w-14"
              >
                <Icon aria-hidden="true" className="h-5 w-5" />
              </a>
            </li>
          ))}
        </ul>
      </FadeIn>

      <footer
        className="mx-auto mt-24 flex max-w-7xl flex-col items-center gap-4 pt-8 text-sm text-[#D7E2EA]/60 md:flex-row md:justify-between"
        style={{ borderTop: '1px solid rgba(215, 226, 234, 0.15)' }}
      >
        <p>
          © {new Date().getFullYear()} {site.name}. All rights reserved.
        </p>
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="inline-flex items-center gap-2 uppercase tracking-wider transition-opacity hover:opacity-70"
        >
          Back to top
          <ArrowUp aria-hidden="true" className="h-4 w-4" />
        </button>
      </footer>
    </section>
  );
}
