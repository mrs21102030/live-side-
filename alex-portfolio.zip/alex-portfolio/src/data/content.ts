/**
 * ─────────────────────────────────────────────────────────────
 *  ALL EDITABLE CONTENT LIVES HERE.
 *  Change names, texts, links, prices and images without touching components.
 *  Images: replace placeholder calls with real paths, e.g. '/images/nova-1.webp'.
 *  Marquee items may also be videos ('/videos/demo.mp4' or '.webm').
 * ─────────────────────────────────────────────────────────────
 */
import { mockup, mockupTall, portraitPlaceholder } from '../lib/placeholders';

export const site = {
  name: 'Alex',
  role: 'Web Developer',
  email: 'hello@alex.dev',
  /** Transparent cutout photo. Put your file in /public and set this to '/portrait.png'. */
  portrait: portraitPlaceholder,
  /** Create a free form at formspree.io and paste its endpoint here. */
  formspreeEndpoint: 'https://formspree.io/f/YOUR_FORM_ID',
  socials: {
    github: 'https://github.com/',
    linkedin: 'https://www.linkedin.com/',
    twitter: 'https://x.com/',
  },
};

export const nav = [
  { label: 'About', href: '#about' },
  { label: 'Projects', href: '#projects' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Contact', href: '#contact' },
];

export const hero = {
  tagline: 'a full-stack web developer building fast, scalable and unforgettable websites',
};

const marqueeBrands = [
  'Lumen', 'Orbit', 'Kora', 'Vanta', 'Nimbus', 'Halo', 'Zenith', 'Pixel',
  'Arcline', 'Flux', 'Mira', 'Terra', 'Nova', 'Pulse', 'Atlas', 'Vertex',
];

/** 16 items: first 8 = row 1, last 8 = row 2. Images or .mp4/.webm videos. */
export const marqueeItems: string[] = marqueeBrands.map((brand, i) => mockup(i, brand));

export const about = {
  text: "With more than five years of experience in web development, i build fast, responsive and scalable websites — from pixel-perfect frontends to solid backends and APIs. I love working with businesses that want a website that performs as good as it looks. Let's build something incredible together!",
  stack: ['React', 'Next.js', 'TypeScript', 'Node.js', 'Laravel', 'WordPress', 'Shopify', 'Tailwind CSS', 'Three.js'],
};

export const services = [
  {
    title: 'Frontend Development',
    description:
      'Pixel-perfect, responsive interfaces built with React, Next.js and modern CSS — fast, accessible and smooth on every device.',
  },
  {
    title: 'Backend & APIs',
    description:
      'Secure, scalable server-side logic, databases and REST/GraphQL APIs that keep your product reliable as it grows.',
  },
  {
    title: 'WordPress & Shopify',
    description: 'Custom themes, plugins and store setups that are easy to manage, built for speed and ready to sell.',
  },
  {
    title: 'E-commerce Solutions',
    description:
      'Conversion-focused online stores with smooth checkout, payment integrations and inventory that runs itself.',
  },
  {
    title: 'Performance & SEO',
    description:
      'Core Web Vitals optimization, technical SEO and clean code that help your website rank higher and load faster.',
  },
];

export type Project = {
  name: string;
  category: string;
  tech: string[];
  url: string;
  images: { col1Top: string; col1Bottom: string; col2: string };
};

export const projects: Project[] = [
  {
    name: 'Nova Commerce',
    category: 'Client',
    tech: ['Next.js', 'Shopify', 'Stripe'],
    url: 'https://example.com',
    images: { col1Top: mockup(1, 'Nova'), col1Bottom: mockup(9, 'Nova'), col2: mockupTall(1, 'Nova') },
  },
  {
    name: 'Pulse Analytics',
    category: 'Personal',
    tech: ['React', 'Node.js', 'PostgreSQL'],
    url: 'https://example.com',
    images: { col1Top: mockup(4, 'Pulse'), col1Bottom: mockup(2, 'Pulse'), col2: mockupTall(4, 'Pulse') },
  },
  {
    name: 'Atlas Realty',
    category: 'Client',
    tech: ['Laravel', 'Tailwind', 'MySQL'],
    url: 'https://example.com',
    images: { col1Top: mockup(3, 'Atlas'), col1Bottom: mockup(6, 'Atlas'), col2: mockupTall(3, 'Atlas') },
  },
];

export const pricing = [
  {
    name: 'Starter',
    price: '$499',
    description: 'Landing page or single-page website',
    features: ['Up to 1 page', 'Responsive design', 'Basic SEO setup', 'Contact form', '1 revision round'],
    highlighted: false,
  },
  {
    name: 'Business',
    price: '$1,499',
    description: 'Multi-page website for growing brands',
    features: ['Up to 8 pages', 'CMS integration', 'Speed optimization', 'On-page SEO', '3 revision rounds'],
    highlighted: true,
  },
  {
    name: 'Custom',
    price: "Let's talk",
    description: 'Web apps, e-commerce and complex builds',
    features: ['Custom features', 'API integrations', 'E-commerce', 'Ongoing support', 'Unlimited scope planning'],
    highlighted: false,
  },
];

export const contact = {
  heading: "Let's talk",
  subtext: "Have a project in mind? Tell me about it and i'll get back to you within 24 hours.",
  budgets: ['< $500', '$500 – $1,500', '$1,500 – $5,000', '$5,000+'],
  successMessage: "Thanks! I'll be in touch soon.",
};
