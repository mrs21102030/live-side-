import FadeIn from '../components/FadeIn';
import { services } from '../data/content';

export default function ServicesSection() {
  return (
    <section
      id="services"
      className="relative rounded-t-[40px] bg-white px-5 pb-32 pt-20 sm:rounded-t-[50px] sm:px-8 sm:pb-36 sm:pt-24 md:rounded-t-[60px] md:px-10 md:pb-44 md:pt-32"
    >
      <FadeIn
        as="h2"
        y={40}
        className="mb-16 text-center font-black uppercase leading-none tracking-tight text-[#0C0C0C] sm:mb-20 md:mb-28"
        style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
      >
        Services
      </FadeIn>

      <ol className="mx-auto max-w-5xl">
        {services.map((service, i) => (
          <FadeIn
            as="li"
            key={service.title}
            delay={i * 0.1}
            className="flex items-start gap-5 py-8 text-[#0C0C0C] sm:gap-10 sm:py-10 md:gap-16 md:py-12"
            style={{ borderTop: i === 0 ? 'none' : '1px solid rgba(12, 12, 12, 0.15)' }}
          >
            <span className="shrink-0 font-black leading-none" style={{ fontSize: 'clamp(3rem, 10vw, 140px)', minWidth: '1.3em' }} aria-hidden="true">
              {String(i + 1).padStart(2, '0')}
            </span>
            <div className="flex flex-col gap-2 pt-1 sm:gap-3 md:pt-3">
              <h3 className="font-medium uppercase leading-tight" style={{ fontSize: 'clamp(1rem, 2.2vw, 2.1rem)' }}>
                {service.title}
              </h3>
              <p className="max-w-2xl font-light leading-relaxed opacity-60" style={{ fontSize: 'clamp(0.85rem, 1.6vw, 1.25rem)' }}>
                {service.description}
              </p>
            </div>
          </FadeIn>
        ))}
      </ol>
    </section>
  );
}
