import { useEffect, useRef, type ReactNode } from 'react';
import { useReducedMotion } from 'framer-motion';

type MagnetProps = {
  children: ReactNode;
  padding?: number;
  strength?: number;
  activeTransition?: string;
  inactiveTransition?: string;
  className?: string;
};

/**
 * Mouse-following magnetic effect. Listens on window (so it keeps working when
 * the content has pointer-events: none) and measures an untransformed outer box.
 * Writes the transform straight to the DOM — no React re-render per mousemove.
 */
export default function Magnet({
  children,
  padding = 100,
  strength = 2,
  activeTransition = 'transform 0.3s ease-out',
  inactiveTransition = 'transform 0.6s ease-in-out',
  className,
}: MagnetProps) {
  const outerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();

  useEffect(() => {
    if (reduce) return;
    if (window.matchMedia('(hover: none)').matches) return;

    let frame = 0;
    let active = false;

    const onMove = (e: MouseEvent) => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const outer = outerRef.current;
        const inner = innerRef.current;
        if (!outer || !inner) return;
        const rect = outer.getBoundingClientRect();
        const dx = e.clientX - (rect.left + rect.width / 2);
        const dy = e.clientY - (rect.top + rect.height / 2);
        const inside = Math.abs(dx) < rect.width / 2 + padding && Math.abs(dy) < rect.height / 2 + padding;

        if (inside) {
          if (!active) inner.style.transition = activeTransition;
          active = true;
          inner.style.transform = `translate3d(${dx / strength}px, ${dy / strength}px, 0)`;
        } else if (active) {
          active = false;
          inner.style.transition = inactiveTransition;
          inner.style.transform = 'translate3d(0, 0, 0)';
        }
      });
    };

    window.addEventListener('mousemove', onMove, { passive: true });
    return () => {
      window.removeEventListener('mousemove', onMove);
      cancelAnimationFrame(frame);
    };
  }, [padding, strength, activeTransition, inactiveTransition, reduce]);

  return (
    <div ref={outerRef} className={className}>
      <div ref={innerRef} style={{ transform: 'translate3d(0, 0, 0)', transition: inactiveTransition, willChange: 'transform' }}>
        {children}
      </div>
    </div>
  );
}
