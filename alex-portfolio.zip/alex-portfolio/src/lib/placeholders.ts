/**
 * Built-in placeholder artwork (SVG data URIs), so the page works offline and
 * never depends on hotlinked images. Replace them in src/data/content.ts with
 * real screenshots (/images/...) or videos (.mp4 / .webm) when ready.
 */

const palettes: [string, string, string][] = [
  ['#18011F', '#B600A8', '#7621B0'],
  ['#0B1320', '#2563EB', '#38BDF8'],
  ['#1A0F05', '#BE4C00', '#F59E0B'],
  ['#06140F', '#059669', '#34D399'],
  ['#140A1F', '#7621B0', '#EC4899'],
  ['#0F172A', '#64748B', '#BBCCD7'],
  ['#1F0A0A', '#DC2626', '#FB923C'],
  ['#0A1A1F', '#0891B2', '#A78BFA'],
];

const toUri = (svg: string) => `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
const W = (o: number) => `fill="#FFFFFF" fill-opacity="${o}"`;
const FONT = `font-family="Helvetica, Arial, sans-serif"`;

function defs(bg: string, a: string, b: string) {
  return `<defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${bg}"/><stop offset="1" stop-color="#050505"/></linearGradient>
    <linearGradient id="ac" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>
    <radialGradient id="glow" cx=".72" cy=".42" r=".55"><stop offset="0" stop-color="${a}" stop-opacity=".55"/><stop offset="1" stop-color="${a}" stop-opacity="0"/></radialGradient>
  </defs>`;
}

function chrome(width: number, label: string) {
  return `<rect width="${width}" height="40" ${W(0.06)}/>
    <circle cx="22" cy="20" r="6" fill="#FF5F57" fill-opacity=".85"/>
    <circle cx="42" cy="20" r="6" fill="#FEBC2E" fill-opacity=".85"/>
    <circle cx="62" cy="20" r="6" fill="#28C840" fill-opacity=".85"/>
    <rect x="${width / 2 - 120}" y="12" width="240" height="16" rx="8" ${W(0.08)}/>
    <text x="40" y="82" ${FONT} font-size="18" font-weight="700" ${W(0.9)}>${label}</text>`;
}

function navLinks(width: number) {
  return [0, 1, 2, 3].map((i) => `<rect x="${width - 300 + i * 64}" y="72" width="44" height="8" rx="4" ${W(0.35)}/>`).join('');
}

function wideLayout(kind: number) {
  switch (kind) {
    case 0:
      return `<rect x="40" y="150" width="340" height="34" rx="8" ${W(0.9)}/>
        <rect x="40" y="196" width="280" height="34" rx="8" fill="url(#ac)"/>
        <rect x="40" y="252" width="300" height="10" rx="5" ${W(0.4)}/>
        <rect x="40" y="272" width="250" height="10" rx="5" ${W(0.4)}/>
        <rect x="40" y="306" width="130" height="40" rx="20" fill="url(#ac)"/>
        <rect x="182" y="306" width="110" height="40" rx="20" fill="none" stroke="#FFFFFF" stroke-opacity=".5"/>
        <circle cx="620" cy="260" r="120" fill="url(#ac)"/>
        <circle cx="620" cy="260" r="158" fill="none" stroke="#FFFFFF" stroke-opacity=".15"/>
        ${[0, 1, 2, 3, 4].map((i) => `<rect x="${40 + i * 120}" y="470" width="80" height="10" rx="5" ${W(0.2)}/>`).join('')}`;
    case 1:
      return `<rect x="230" y="120" width="380" height="30" rx="8" ${W(0.9)}/>
        <rect x="270" y="160" width="300" height="30" rx="8" fill="url(#ac)"/>
        <rect x="290" y="206" width="260" height="10" rx="5" ${W(0.4)}/>
        <rect x="360" y="232" width="120" height="34" rx="17" fill="url(#ac)"/>
        ${[40, 302, 564]
          .map(
            (x) => `<rect x="${x}" y="300" width="236" height="200" rx="18" ${W(0.06)} stroke="#FFFFFF" stroke-opacity=".1"/>
            <rect x="${x + 20}" y="320" width="196" height="100" rx="12" fill="url(#ac)" fill-opacity=".75"/>
            <rect x="${x + 20}" y="438" width="140" height="10" rx="5" ${W(0.7)}/>
            <rect x="${x + 20}" y="458" width="100" height="8" rx="4" ${W(0.3)}/>`,
          )
          .join('')}`;
    default:
      return `<rect x="0" y="100" width="170" height="440" ${W(0.04)}/>
        ${[0, 1, 2, 3, 4].map((i) => `<rect x="24" y="${130 + i * 40}" width="${i === 0 ? 120 : 96}" height="10" rx="5" ${i === 0 ? 'fill="url(#ac)"' : W(0.3)}/>`).join('')}
        ${[200, 410, 620]
          .map(
            (x, i) => `<rect x="${x}" y="110" width="190" height="80" rx="14" ${W(0.06)}/>
            <rect x="${x + 18}" y="130" width="60" height="8" rx="4" ${W(0.35)}/>
            <rect x="${x + 18}" y="150" width="${90 + i * 10}" height="20" rx="6" ${W(0.85)}/>`,
          )
          .join('')}
        <rect x="200" y="210" width="610" height="200" rx="16" ${W(0.05)}/>
        <path d="M220 380 L300 340 L380 360 L460 300 L540 320 L620 260 L700 280 L790 230" fill="none" stroke="url(#ac)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
        ${[0, 1, 2].map((i) => `<rect x="200" y="${430 + i * 30}" width="610" height="20" rx="6" ${W(0.04 + (i % 2) * 0.02)}/>`).join('')}`;
  }
}

/** Landscape website mockup (840×540). */
export function mockup(seed: number, label = 'Studio'): string {
  const [bg, a, b] = palettes[seed % palettes.length];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 840 540" width="840" height="540">
    ${defs(bg, a, b)}
    <rect width="840" height="540" fill="url(#bg)"/>
    <rect width="840" height="540" fill="url(#glow)"/>
    ${chrome(840, label)}
    ${navLinks(840)}
    ${wideLayout(seed % 3)}
  </svg>`;
  return toUri(svg);
}

/** Tall mobile-style mockup (600×800) for the large project column. */
export function mockupTall(seed: number, label = 'Studio'): string {
  const [bg, a, b] = palettes[seed % palettes.length];
  const cards = [
    [40, 630],
    [310, 630],
  ]
    .map(
      ([x, y]) =>
        `<rect x="${x}" y="${y}" width="250" height="140" rx="20" ${W(0.06)} stroke="#FFFFFF" stroke-opacity=".1"/><rect x="${x + 20}" y="${y + 20}" width="80" height="80" rx="16" fill="url(#ac)" fill-opacity=".7"/><rect x="${x + 116}" y="${y + 30}" width="110" height="10" rx="5" ${W(0.7)}/><rect x="${x + 116}" y="${y + 50}" width="80" height="8" rx="4" ${W(0.3)}/>`,
    )
    .join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800" width="600" height="800">
    ${defs(bg, a, b)}
    <rect width="600" height="800" fill="url(#bg)"/>
    <rect width="600" height="800" fill="url(#glow)"/>
    ${chrome(600, label)}
    <rect x="530" y="68" width="30" height="4" rx="2" ${W(0.6)}/><rect x="530" y="78" width="30" height="4" rx="2" ${W(0.6)}/>
    <rect x="40" y="120" width="520" height="260" rx="28" fill="url(#ac)"/>
    <circle cx="430" cy="230" r="70" ${W(0.18)}/>
    <rect x="40" y="410" width="420" height="30" rx="8" ${W(0.9)}/>
    <rect x="40" y="450" width="320" height="30" rx="8" ${W(0.9)}/>
    <rect x="40" y="500" width="460" height="10" rx="5" ${W(0.4)}/>
    <rect x="40" y="520" width="380" height="10" rx="5" ${W(0.4)}/>
    <rect x="40" y="556" width="160" height="44" rx="22" fill="url(#ac)"/>
    ${cards}
  </svg>`;
  return toUri(svg);
}

/** Transparent head-and-shoulders silhouette used until a real cutout photo is added. */
export const portraitPlaceholder = toUri(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 640" width="520" height="640">
  <defs>
    <radialGradient id="halo" cx=".5" cy=".62" r=".5"><stop offset="0" stop-color="#B600A8" stop-opacity=".45"/><stop offset=".6" stop-color="#7621B0" stop-opacity=".15"/><stop offset="1" stop-color="#7621B0" stop-opacity="0"/></radialGradient>
    <linearGradient id="body" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#26272E"/><stop offset="1" stop-color="#0C0C0C"/></linearGradient>
    <linearGradient id="rim" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#B600A8"/><stop offset=".5" stop-color="#7621B0"/><stop offset="1" stop-color="#BE4C00"/></linearGradient>
  </defs>
  <ellipse cx="260" cy="400" rx="260" ry="240" fill="url(#halo)"/>
  <path d="M40 640 C40 505 138 438 214 426 L214 372 C170 344 150 292 152 230 C154 150 200 104 260 104 C320 104 366 150 368 230 C370 292 350 344 306 372 L306 426 C382 438 480 505 480 640 Z" fill="url(#body)" stroke="url(#rim)" stroke-width="3"/>
</svg>`);
