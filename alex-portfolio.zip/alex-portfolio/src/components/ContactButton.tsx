import type { CSSProperties } from 'react';

type ContactButtonProps = {
  label?: string;
  href?: string;
  onClick?: () => void;
  type?: 'button' | 'submit';
  disabled?: boolean;
  className?: string;
};

const gradientStyle: CSSProperties = {
  background: 'linear-gradient(123deg, #18011F 7%, #B600A8 37%, #7621B0 72%, #BE4C00 100%)',
  boxShadow: '0px 4px 4px rgba(181, 1, 167, 0.25), 4px 4px 12px #7721B1 inset',
  outline: '2px solid #FFFFFF',
  outlineOffset: '-3px',
};

const base =
  'inline-flex items-center justify-center rounded-full text-white font-medium uppercase tracking-widest whitespace-nowrap ' +
  'px-8 py-3 sm:px-10 sm:py-3.5 md:px-12 md:py-4 text-xs sm:text-sm md:text-base ' +
  'transition-[transform,filter] duration-200 hover:scale-[1.03] hover:brightness-110 ' +
  'focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-4 focus-visible:ring-offset-[#0C0C0C] ' +
  'disabled:pointer-events-none disabled:opacity-60';

export default function ContactButton({
  label = 'Contact Me',
  href,
  onClick,
  type = 'button',
  disabled,
  className = '',
}: ContactButtonProps) {
  if (href) {
    return (
      <a href={href} onClick={onClick} className={`${base} ${className}`} style={gradientStyle}>
        {label}
      </a>
    );
  }
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={`${base} ${className}`} style={gradientStyle}>
      {label}
    </button>
  );
}
