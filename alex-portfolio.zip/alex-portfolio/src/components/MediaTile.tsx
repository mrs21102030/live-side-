const isVideo = (src: string) => /\.(mp4|webm)(\?.*)?$/i.test(src);

/** Renders an <img> or a muted autoplay <video> depending on the file extension. */
export default function MediaTile({ src, alt = '', className = '' }: { src: string; alt?: string; className?: string }) {
  if (isVideo(src)) {
    return <video src={src} className={className} autoPlay muted loop playsInline preload="metadata" aria-hidden={alt ? undefined : true} />;
  }
  return <img src={src} alt={alt} loading="lazy" decoding="async" draggable={false} className={className} />;
}
