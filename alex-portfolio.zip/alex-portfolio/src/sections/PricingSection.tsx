import { Check } from 'lucide-react';
import FadeIn from '../components/FadeIn';
import ContactButton from '../components/ContactButton';
import { pricing } from '../data/content';

export default function PricingSection() {
  return (
    <section
      id="pricing"
      className="relative z-20 -mt-10 rounded-t-[40px] bg-white px-5 pb-32 pt-20 sm:-mt-12 sm:rounded-t-[50px] sm:px-8 sm:pb-36 sm:pt-24 md:-mt-14 md:rounded-t-[60px] md:px-10 md:pb-44 md:pt-32"
    >
      <FadeIn
        as="h2"
        y={40}
        className="mb-16 text-center font-black uppercase leading-none tracking-tight text-[#0C0C0C] sm:mb-20 md:mb-24"
        style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
      >
        Pricing
      </FadeIn>

      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-5 lg:grid-cols-3">
        {pricing.map((plan, i) => {
          const dark = plan.highlighted;
          return (
            <FadeIn
              key={plan.name}
              delay={i * 0.1}
              className={`relative flex flex-col rounded-[32px] p-8 md:rounded-[40px] md:p-10 ${dark ? 'bg-[#0C0C0C] text-[#D7E2EA]' : 'text-[#0C0C0C]'}`}
              style={{ border: dark ? '1px solid #0C0C0C' : '1px solid rgba(12, 12, 12, 0.15)' }}
            >
              <div className="mb-6 flex items-center justify-between gap-3">
                <h3 className="text-lg font-medium uppercase tracking-wider md:text-xl">{plan.name}</h3>
                {dark && (
                  <span className="rounded-full border border-[#D7E2EA]/30 px-3 py-1 text-xs uppercase tracking-wider text-[#D7E2EA]/80">
                    Most popular
                  </span>
                )}
              </div>

              <p
                className={`mb-3 whitespace-nowrap font-black leading-none ${dark ? 'hero-heading' : ''}`}
                style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}
              >
                {plan.price}
              </p>
              <p className="mb-8 font-light opacity-60">{plan.description}</p>

              <ul className="mb-10 flex flex-col gap-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3 font-light">
                    <Check aria-hidden="true" className={`h-5 w-5 shrink-0 ${dark ? 'text-[#B600A8]' : 'text-[#0C0C0C]'}`} strokeWidth={2.5} />
                    {feature}
                  </li>
                ))}
              </ul>

              <div className="mt-auto">
                {dark ? (
                  <ContactButton href="#contact" label="Get Started" className="w-full" />
                ) : (
                  <a
                    href="#contact"
                    className="inline-flex w-full items-center justify-center rounded-full border-2 border-[#0C0C0C] px-8 py-3 text-xs font-medium uppercase tracking-widest text-[#0C0C0C] transition-colors duration-200 hover:bg-[#0C0C0C]/5 sm:px-10 sm:py-3.5 sm:text-sm md:py-4 md:text-base"
                  >
                    Get Started
                  </a>
                )}
              </div>
            </FadeIn>
          );
        })}
      </div>
    </section>
  );
}
