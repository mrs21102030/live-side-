import { motion, useReducedMotion } from 'framer-motion';
import type { CSSProperties, ElementType, ReactNode } from 'react';

// Motion components are created once per element type (never inside render).
const cache = new Map<ElementType, ElementType>();
function getMotionComponent(as: ElementType): ElementType {
  let comp = cache.get(as);
  if (!comp) {
    comp =
      typeof as === 'string'
        ? ((motion as unknown as Record<string, ElementType>)[as] ?? motion.div)
        : (motion.create(as as never) as unknown as ElementType);
    cache.set(as, comp);
  }
  return comp;
}

type FadeInProps = {
  as?: ElementType;
  delay?: number;
  duration?: number;
  x?: number;
  y?: number;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
  [key: string]: unknown;
};

export default function FadeIn({
  as = 'div',
  delay = 0,
  duration = 0.7,
  x = 0,
  y = 30,
  className,
  style,
  children,
  ...rest
}: FadeInProps) {
  const reduce = useReducedMotion();

  if (reduce) {
    const Tag = as;
    return (
      <Tag className={className} style={style} {...rest}>
        {children}
      </Tag>
    );
  }

  const MotionTag = getMotionComponent(as);
  return (
    <MotionTag
      initial={{ opacity: 0, x, y }}
      whileInView={{ opacity: 1, x: 0, y: 0 }}
      viewport={{ once: true, margin: '50px', amount: 0 }}
      transition={{ duration, delay, ease: [0.25, 0.1, 0.25, 1] }}
      className={className}
      style={style}
      {...rest}
    >
      {children}
    </MotionTag>
  );
}
