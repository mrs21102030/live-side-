# Alex — Web Developer Portfolio

Single-page portfolio built with React 18, TypeScript, Vite, Tailwind CSS 3.4, Framer Motion 12 and Lucide React.

## Run locally

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build in /dist
npm run preview  # preview the production build
```

## Customize (everything is in `src/data/content.ts`)

| What | Where |
|---|---|
| Name, email, social links | `site` |
| Portrait photo | Put a transparent cutout in `/public/portrait.png`, set `site.portrait = '/portrait.png'` |
| Contact form | Create a form at formspree.io, paste the endpoint into `site.formspreeEndpoint` |
| Marquee (16 items) | `marqueeItems` — image paths or `.mp4` / `.webm` videos (first 8 = row 1, last 8 = row 2) |
| About text + tech pills | `about` |
| Services | `services` |
| Projects (name, category, tech, live URL, 3 images) | `projects` |
| Pricing plans | `pricing` |
| Contact heading, budgets, success text | `contact` |

Placeholder images are generated SVG mockups (`src/lib/placeholders.ts`) so the site works offline. Replace them with real screenshots, e.g. `/images/nova-1.webp` in `/public/images/`.

Also update `index.html`: title, meta description and `og:image` (add a 1200×630 image to `/public`).

## Structure

```
src/
  data/content.ts        all editable content
  lib/placeholders.ts    placeholder artwork generator
  components/            FadeIn, Magnet, AnimatedText, ContactButton, LiveProjectButton, MediaTile
  sections/              Hero, Marquee, About, Services, Projects, Pricing, Contact (+ footer)
```

## Notes

- `overflowX: 'clip'` on the main wrapper is intentional — `overflow: hidden` would break the sticky project cards.
- Motion respects `prefers-reduced-motion`.
- Kanit loads only weights 300, 500 and 900.

## Deploy

Push to GitHub and import in Vercel or Netlify (build: `npm run build`, output: `dist`).
