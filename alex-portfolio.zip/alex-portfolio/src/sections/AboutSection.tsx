import { motion, useReducedMotion } from 'framer-motion';
import { Code2, Database, Rocket, Terminal, type LucideIcon } from 'lucide-react';
import FadeIn from '../components/FadeIn';
import AnimatedText from '../components/AnimatedText';
import ContactButton from '../components/ContactButton';
import { about } from '../data/content';

type Tile = {
  Icon: LucideIcon;
  position: string;
  width: string;
  rotate: number;
  delay: number;
  fromX: number;
  floatDelay: number;
};

const tiles: Tile[] = [
  { Icon: Code2, position: 'top-[4%] left-[2%] md:left-[4%]', width: 'w-[100px] sm:w-[130px] md:w-[170px]', rotate: -12, delay: 0.1, fromX: -80, floatDelay: 0 },
  { Icon: Database, position: 'bottom-[8%] left-[4%] md:left-[10%]', width: 'w-[85px] sm:w-[115px] md:w-[150px]', rotate: 8, delay: 0.25, fromX: -80, floatDelay: 1.5 },
  { Icon: Terminal, position: 'top-[4%] right-[2%] md:right-[4%]', width: 'w-[100px] sm:w-[130px] md:w-[170px]', rotate: 12, delay: 0.15, fromX: 80, floatDelay: 0.8 },
  { Icon: Rocket, position: 'bottom-[8%] right-[4%] md:right-[10%]', width: 'w-[110px] sm:w-[140px] md:w-[180px]', rotate: -8, delay: 0.3, fromX: 80, floatDelay: 2.2 },
];

function GlassTile({ tile }: { tile: Tile }) {
  const reduce = useReducedMotion();
  const { Icon } = tile;
  return (
    <FadeIn aria-hidden="true" delay={tile.delay} x={tile.fromX} y={0} duration={0.9} className={`pointer-events-none absolute z-0 ${tile.position} ${tile.width}`}>
      <motion.div
        animate={reduce ? undefined : { y: [0, -10, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: tile.floatDelay }}
      >
        <div
          className="flex aspect-square w-full items-center justify-center rounded-[28px] backdrop-blur-md md:rounded-[36px]"
          style={{
            transform: `rotate(${tile.rotate}deg)`,
            background: 'linear-gradient(135deg, rgba(182,0,168,0.25), rgba(118,33,176,0.15) 50%, rgba(190,76,0,0.2))',
            border: '1px solid rgba(215,226,234,0.15)',
            boxShadow: '4px 4px 12px rgba(119,33,177,0.6) inset, 0 20px 40px rgba(0,0,0,0.35)',
          }}
        >
          <Icon className="h-[40%] w-[40%] text-[#D7E2EA]" strokeWidth={1.5} />
        </div>
      </motion.div>
    </FadeIn>
  );
}

export default function AboutSection() {
  return (
    <section id="about" className="relative flex min-h-svh flex-col items-center justify-center px-5 py-20 sm:px-8 md:px-10" style={{ overflowX: 'clip' }}>
      {tiles.map((tile, i) => (
        <GlassTile key={i} tile={tile} />
      ))}

      <div className="relative z-10 flex flex-col items-center gap-16 sm:gap-20 md:gap-24">
        <div className="flex flex-col items-center gap-10 sm:gap-14 md:gap-16">
          <FadeIn
            as="h2"
            delay={0}
            y={40}
            className="hero-heading text-center font-black uppercase leading-none tracking-tight"
            style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
          >
            About me
          </FadeIn>

          <div className="flex flex-col items-center gap-8">
            <AnimatedText
              text={about.text}
              className="max-w-[560px] text-center font-medium leading-relaxed text-[#D7E2EA]"
              style={{ fontSize: 'clamp(1rem, 2vw, 1.35rem)' }}
            />
            <FadeIn as="ul" delay={0.2} className="flex max-w-[600px] flex-wrap justify-center gap-2" aria-label="Tech stack">
              {about.stack.map((tech) => (
                <li
                  key={tech}
                  className="rounded-full border border-[#D7E2EA]/25 px-4 py-1.5 text-xs uppercase tracking-wider text-[#D7E2EA]/80 sm:text-sm"
                >
                  {tech}
                </li>
              ))}
            </FadeIn>
          </div>
        </div>

        <FadeIn delay={0.1}>
          <ContactButton href="#contact" />
        </FadeIn>
      </div>
    </section>
  );
}
