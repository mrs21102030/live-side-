import { useLayoutEffect, useRef } from 'react';
import { motion, useMotionValue, useReducedMotion, useScroll, useTransform, type MotionValue } from 'framer-motion';
import MediaTile from '../components/MediaTile';
import { marqueeItems } from '../data/content';

const TRAVEL = 600; // px each row travels while the section crosses the viewport

function MarqueeRow({ items, progress, direction }: { items: string[]; progress: MotionValue<number>; direction: 1 | -1 }) {
  const trackRef = useRef<HTMLDivElement>(null);
  const setWidth = useMotionValue(0);
  const reduce = useReducedMotion();
  const travel = reduce ? 0 : TRAVEL;

  // Width of ONE set (tiles + gaps). Rows start at -setWidth so neither edge ever shows a gap.
  useLayoutEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    const measure = () => {
      const gap = parseFloat(getComputedStyle(track).columnGap) || 0;
      setWidth.set((track.scrollWidth + gap) / 3);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(track);
    return () => ro.disconnect();
  }, [setWidth]);

  const x = useTransform<number, number>([progress, setWidth], ([p, w]) => -w + direction * p * travel);
  const tripled = [...items, ...items, ...items];

  return (
    <motion.div ref={trackRef} className="flex w-max gap-3" style={{ x, willChange: 'transform' }}>
      {tripled.map((src, i) => (
        <MediaTile
          key={i}
          src={src}
          className="h-[168px] w-[260px] flex-shrink-0 rounded-2xl object-cover md:h-[270px] md:w-[420px]"
        />
      ))}
    </motion.div>
  );
}

export default function MarqueeSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start end', 'end start'] });
  const half = Math.ceil(marqueeItems.length / 2);

  return (
    <section ref={sectionRef} aria-hidden="true" className="flex flex-col gap-3 bg-[#0C0C0C] pb-10 pt-24 sm:pt-32 md:pt-40" style={{ overflowX: 'clip' }}>
      <MarqueeRow items={marqueeItems.slice(0, half)} progress={scrollYProgress} direction={1} />
      <MarqueeRow items={marqueeItems.slice(half)} progress={scrollYProgress} direction={-1} />
    </section>
  );
}
