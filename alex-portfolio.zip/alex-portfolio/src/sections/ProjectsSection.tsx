import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform, type MotionValue } from 'framer-motion';
import FadeIn from '../components/FadeIn';
import LiveProjectButton from '../components/LiveProjectButton';
import { projects, type Project } from '../data/content';

const imageRadius = 'rounded-[28px] sm:rounded-[50px] md:rounded-[60px]';

function ProjectCard({
  project,
  index,
  total,
  progress,
}: {
  project: Project;
  index: number;
  total: number;
  progress: MotionValue<number>;
}) {
  const reduce = useReducedMotion();
  const targetScale = 1 - (total - 1 - index) * 0.03;
  const scale = useTransform(progress, [index / total, 1], [1, reduce ? 1 : targetScale]);

  return (
    // The WRAPPER is sticky, so all cards share one scroll parent and actually stack.
    <div className="sticky top-0 flex h-[85vh] items-start justify-center pt-24 md:pt-32">
      <motion.article
        className="relative w-full max-w-7xl rounded-[40px] border-2 border-[#D7E2EA] bg-[#0C0C0C] p-4 sm:rounded-[50px] sm:p-6 md:rounded-[60px] md:p-8"
        style={{ top: index * 28, scale, transformOrigin: 'top center' }}
      >
        <header className="mb-4 flex flex-col gap-4 px-2 sm:mb-6 md:flex-row md:items-end md:justify-between md:px-4">
          <div className="flex items-end gap-4 sm:gap-6 md:gap-8">
            <span
              className="font-black leading-[0.8] text-[#D7E2EA]"
              style={{ fontSize: 'min(clamp(3rem, 8vw, 120px), 13svh)' }}
              aria-hidden="true"
            >
              {String(index + 1).padStart(2, '0')}
            </span>
            <div className="flex flex-col gap-1 pb-1">
              <span className="text-xs uppercase tracking-widest text-[#D7E2EA]/60 sm:text-sm">{project.category}</span>
              <h3 className="font-medium uppercase leading-tight text-[#D7E2EA]" style={{ fontSize: 'clamp(1.2rem, 2.6vw, 2.4rem)' }}>
                {project.name}
              </h3>
              <span className="text-xs text-[#D7E2EA]/60 sm:text-sm">{project.tech.join(' · ')}</span>
            </div>
          </div>
          <div className="shrink-0">
            <LiveProjectButton href={project.url} />
          </div>
        </header>

        <div className="grid grid-cols-[2fr_3fr] gap-3 sm:gap-4">
          <div className="flex flex-col gap-3 sm:gap-4">
            <img
              src={project.images.col1Top}
              alt={`${project.name} — desktop screen`}
              loading="lazy"
              className={`w-full object-cover ${imageRadius}`}
              style={{ height: 'min(clamp(120px, 15vw, 210px), 20svh)' }}
            />
            <img
              src={project.images.col1Bottom}
              alt={`${project.name} — inner page`}
              loading="lazy"
              className={`w-full object-cover ${imageRadius}`}
              style={{ height: 'min(clamp(150px, 20vw, 300px), 28svh)' }}
            />
          </div>
          <img
            src={project.images.col2}
            alt={`${project.name} — mobile view`}
            loading="lazy"
            className={`h-full min-h-0 w-full object-cover ${imageRadius}`}
          />
        </div>
      </motion.article>
    </div>
  );
}

export default function ProjectsSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ['start start', 'end end'] });

  return (
    <section
      id="projects"
      className="relative z-10 -mt-10 rounded-t-[40px] bg-[#0C0C0C] px-5 pb-32 pt-20 sm:-mt-12 sm:rounded-t-[50px] sm:px-8 md:-mt-14 md:rounded-t-[60px] md:px-10 md:pt-28"
    >
      <FadeIn
        as="h2"
        y={40}
        className="hero-heading text-center font-black uppercase leading-none tracking-tight"
        style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
      >
        Projects
      </FadeIn>

      <div ref={containerRef} className="relative">
        {projects.map((project, i) => (
          <ProjectCard key={project.name} project={project} index={i} total={projects.length} progress={scrollYProgress} />
        ))}
      </div>
    </section>
  );
}
